/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package laura.app.analizador.manejo_diccionario;

import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;
import laura.app.analizador.archivos.ArchivoDiccionario;
import laura.app.analizador.validaciones.ValidacionBasicaCadena;

/**
 *
 * @author Laura Camacho, Jessica Garcia y Alan Bohorquez
 */

/* Se hace una busqueda en el diccionario por medio de tres niveles; palabra, 
palabra con complemento y oración.
Palabra: Unica, no es valido una sola letra
Palabra con complemento: Se entiende por palabras que vayan acompañadas, es decir
"Por que" "Sin embargo" "Tal vez"
Oración: Se trata de encontrar un sentido a las palabras, al estar todas en una
frase se pueden ver más sugerencias.
 */

public class BusquedadDiccionario {

    private Set coincidenciasL1;
    private Set coincidenciasL2;
    private Set coincidenciasL3;
    
    /*
    La primera evaluación se hace por medio de palabras individuales, es decir, una
    cadena básica, la evaluación se hace comprobando que no sea un caracter nulo, se busca en el 
    diccionario y se siguen los demas pasos si el resultado da positivo, es decir, cumple
    para continuar el proceso. De lo contrario no es una palabra válda y se cierra el proceso
    */
    
    public String obtenerPrimeraEvaluacion(String palabra) {
        ArchivoDiccionario diccionario = ArchivoDiccionario.getInstance();
        if (diccionario != null) {
            if (diccionario.getDiccionario().contains(palabra)) {
                return palabra;
            } else {
                String resultadoValidacionBasica = new ValidacionBasicaCadena().validacionBasicaCadena(palabra);
                if (resultadoValidacionBasica.compareTo("cumple") == 0) {
                    return "Cumple";
                }
            }
        }
        return "No es una palabra Valida";
    }
    /* Método usado para obtener las coincidencias más cercanas en el diccionario
    dependiendo de la palabra ingresada, se trata de buscar las primeras tres letras de la 
    palabra hacia adelante y hacia atras 
    - Las sugerencias normalmente no son menores de 2
    - Se validan palabras y se encuentran coincidencias con tilde 
    */
    
    public Set<String> obtenerCoincideciasMasCercanas(String palabra) {
        ArchivoDiccionario diccionario = ArchivoDiccionario.getInstance();

        if (palabra.length() > 1) {
            this.coincidenciasL1 = new HashSet<String>();
            this.coincidenciasL2 = new HashSet<String>();
            this.coincidenciasL3 = new HashSet<String>();

            for (int i = 0; i < diccionario.getDiccionario().size(); i++) {
                char letrasPalabraDiccionario[] = diccionario.getDiccionario().get(i).toCharArray();
                char letrasPalabraBuscada[] = palabra.toCharArray();
                int diferenciaLargoPalabraDPalabraB = letrasPalabraBuscada.length - letrasPalabraDiccionario.length;
                int iterador = letrasPalabraBuscada.length;

                if ((Pattern.compile("[á|é|í|ó|ú]").matcher(diccionario.getDiccionario().get(i)).find()
                        || diccionario.getDiccionario().get(i).startsWith(palabra.substring(0, 1)))
                        || diccionario.getDiccionario().get(i).endsWith(palabra.substring(palabra.length() - 1))
                        && (diferenciaLargoPalabraDPalabraB < 3 || diferenciaLargoPalabraDPalabraB > -3)) {

                    int cantidadNoCoincidencias = 0;

                    if (diferenciaLargoPalabraDPalabraB > 0) {
                        iterador = letrasPalabraBuscada.length - diferenciaLargoPalabraDPalabraB;
                    }

                    for (int j = 0; j < iterador; j++) {
                        if (letrasPalabraBuscada[j] != letrasPalabraDiccionario[j]) {
                            cantidadNoCoincidencias++;
                            if (cantidadNoCoincidencias > 2) {
                                break;
                            }
                        }
                    }
                    if (cantidadNoCoincidencias >= 0 && cantidadNoCoincidencias < 2
                            && diferenciaLargoPalabraDPalabraB <= 0
                            && diferenciaLargoPalabraDPalabraB >= -1
                            || (diccionario.getDiccionario().get(i).endsWith(palabra.substring(1))
                            && (diccionario.getDiccionario().get(i).length() - palabra.length() == 1))) {
                        coincidenciasL1.add(diccionario.getDiccionario().get(i));

                    } else if (cantidadNoCoincidencias > 0 && cantidadNoCoincidencias < 3 && diferenciaLargoPalabraDPalabraB > -1) {
                        coincidenciasL2.add(diccionario.getDiccionario().get(i));

                    } else {
                        coincidenciasL3.add(diccionario.getDiccionario().get(i));
                    }
                }
            }
            if (!coincidenciasL1.isEmpty()) {
                return coincidenciasL1;
            } else if (!coincidenciasL2.isEmpty()) {
                return coincidenciasL2;
            } else {
                return coincidenciasL3;
            }

        } else {
            return null;
        }
    }
}
