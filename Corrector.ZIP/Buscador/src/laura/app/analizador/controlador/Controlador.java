/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package laura.app.analizador.controlador;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.regex.Pattern;
import javax.swing.DefaultListModel;
import laura.app.analizador.manejo_diccionario.BusquedadDiccionario;
import laura.app.analizador.modelo.Cadena;
import laura.app.analizador.views.VistaPrincipal;

/**
 *
 * @author Laura Camacho, Jessica Garcia & Alan Bohorquez
 * @clase Controlador donde se especifica cada proceso del programa
 */
public class Controlador {

    /* Principales métodos del programa para su correcto manejo, donde se especifica
    como se hara la busqueda en el diccionario, la lista de palabras predeterminadas
    las cadenas tanto para las palabras erroneas como para las correctas y la 
    vista principal del sistema.
     */
    private final BusquedadDiccionario busquedadDiccionario;
    private final DefaultListModel modelo;
    private final Set<Cadena> cadenasCorrectas;
    private final Set<Cadena> cadenasIncorrectas;
    private final VistaPrincipal vistaPrincipal;

    /* Se usa la clase "HashSet" para determinar de manera facil y sencilla si
    un objeto ya esta en el conjunto o no, en este caso se enfoca en las palabras
    tanto correctas como incorrectas.
     */
    public Controlador(VistaPrincipal vistaPrincipal, BusquedadDiccionario busquedadDiccionario) {
        this.vistaPrincipal = vistaPrincipal;
        this.busquedadDiccionario = busquedadDiccionario;
        this.cadenasCorrectas = new HashSet<>();
        this.cadenasIncorrectas = new HashSet<>();
        this.modelo = (DefaultListModel) this.vistaPrincipal.getjListErrorPalabras().getModel();
        addEvents();
    }

    /* Se adapta este evento el cual se dispara justo cuando la persona comienza
    a escribir, se hace con la intencion de que la busqueda sea mucho más rapida
    y se conozca en cuales palabras tuvo una falla.
    
     */
    private void addEvents() {
        this.vistaPrincipal.getjTextArea().addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                eventoMientraEscribe(e);
                if (e.getKeyCode() == 8) {
                    eventoMientraEscribe(e);
                } else if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
                    eventoMientraEscribe(e);
                }
            }

            @Override
            public void keyReleased(KeyEvent e) {
//                eventoMientraEscribe(e);
            }
        });
        /* Evento del mouse el cual se enfoca principalmente en obtener las 
        palabras sugeridas de la palabra en la cual se falló, se activa con un 
        solo click, esta acción hace que se llene la tabla de sugerencias de la 
        palabra señalada y no de todas, se mantiene un orden.
        
         */
        this.vistaPrincipal.getjListErrorPalabras().addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {

                String palabra = obtenerPalabrasSugeridas(e);
                llenarListaPalabraSugeridasVista(palabra);
            }

            /* Evento del mouse encargado en cambiar la palabra de la cual se 
            obtuvo un error, la acción se realiza por medio de doble click (2)sobre
            la nueva palabra que se quiere añadir al texto.
             */
            @Override
            public void mouseClicked(MouseEvent e) {
                cambioPalabra(e);
            }

        });
        this.vistaPrincipal.getjListSugerenciasP().addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                cambioPalabra(e);
            }
        });
    }

    /* Con el evento de cambio de palabra, reemplazamos el error que tenemos
    en el cuadro principal de texto, esta acción se realiza con doble click.
    La palabra a cambiar se extrae de la lista de error de palabras, cuando la 
    reconoce, la arrastra al cuadro de "errores encontrados" y ahi se activa 
    la nueva palabra con el evento, las sugerencias saldran en el ultimo cuadro.
     */
    private void cambioPalabra(MouseEvent e) {
        if (e.getSource() == this.vistaPrincipal.getjListSugerenciasP()) {

            if (e.getClickCount() == 2) {
                String palabraNueva = this.vistaPrincipal.getjListSugerenciasP().getSelectedValue();
                String palabraACambiar = this.vistaPrincipal.getjListErrorPalabras().getSelectedValue();

                if (palabraACambiar != null && palabraACambiar != null) {
                    String texto = this.vistaPrincipal.getjTextArea().getText();
                    texto = texto.replace(palabraACambiar, palabraNueva);
                    this.vistaPrincipal.getjTextArea().setText(texto);
                    crearYEvaluarSubcadenas(texto);
                }

            }
        }
    }

    /* Con este método comparamos las palabras, al no encontrar coincidencias
    coherentes, se señala como una palabra incorrecta. 
    
     */
    private Cadena buscarPalabraError(String palabra) {
        Iterator<Cadena> it = this.cadenasIncorrectas.iterator();
        while (it.hasNext()) {
            Cadena cadena = it.next();
            if (cadena.getCadena().compareTo(palabra) == 0) {
                return cadena;
            }
        }
        return null;
    }

    /* De cada palabra erronea, de la cual no se encuentre coincidencia en la 
    lista, se traslada al recuadro de "Errores encontrados", aqui, por medio del
    evento, nos dan las alternativas en el ultimo recuadro, este cuadro se 
    identifica gracias a la oración "Quizas quiso decir..."
     */
    private void llenarListaPalabraSugeridasVista(String palabraB) {
        DefaultListModel modelo1 = new DefaultListModel();
        Iterator<Cadena> it = this.cadenasIncorrectas.iterator();

        while (it.hasNext()) {
            Cadena cadena = it.next();
            if (palabraB.compareTo(cadena.getCadena()) == 0) {
                if (!cadena.getCadenasAlternativas().isEmpty()) {
                    this.vistaPrincipal.getjTextFieldSugerencia().setText("Quizás quiso decir...");
                    for (String palabra : cadena.getCadenasAlternativas()) {
                        modelo1.addElement(palabra);
                    }
                }
            }
        }
        this.vistaPrincipal.getjListSugerenciasP().setModel(modelo1);
    }

    /* Para obtener las palabras sugeridas, se examina la palabra erronea, cuando
    se comprueba que no esta nula, se procede a encontrar las alternativas más
    cercanas dependiendo de lo que se haya escrito, todo se hace por medio de 
    una busqueda en el diccionario.
     */
    private String obtenerPalabrasSugeridas(MouseEvent me) {
        if (me.getSource() == this.vistaPrincipal.getjListErrorPalabras()) {
            String palabraB = this.vistaPrincipal.getjListErrorPalabras().getSelectedValue();
            if (palabraB != null) {
                Cadena cadena = buscarPalabraError(palabraB);
                if (cadena != null) {
                    Set<String> listaPalabrasSugeridas = this.busquedadDiccionario.obtenerCoincideciasMasCercanas(cadena.getCadena());
                    if (listaPalabrasSugeridas != null) {
                        Iterator<Cadena> it = this.cadenasIncorrectas.iterator();
                        while (it.hasNext()) {
                            Cadena cadenaEval = it.next();
                            if (cadenaEval == cadena) {
                                cadenaEval.setCadenasAlternativas(listaPalabrasSugeridas);
                                break;
                            }
                        }
                    }
                    return cadena.getCadena();
                }
            }
        }
        return null;
    }

    /* Método para cuando al instante que se active el programa, el usuario pueda ver 
    ver los cuadros, aunque el unico editable es el primero, donde se deposita la palabra 
    o texto, justo cuando comience la escritura, el evento inicia y comienza a evaluar.
     */
    public void start() {
        this.vistaPrincipal.setVisible(true);
    }

    private void eventoMientraEscribe(KeyEvent ke) {
        if (ke.getSource() == this.vistaPrincipal.getjTextArea()) {
            String textoEvaluar = this.vistaPrincipal.getjTextArea().getText();
            crearYEvaluarSubcadenas(textoEvaluar);

            if (ke.getKeyCode() == KeyEvent.VK_ENTER) {
                crearYEvaluarSubcadenas(textoEvaluar);
            }
        }
    }

    /* Para evaluar la palabra y que el proceso sea rápido, se usa una expresión 
    regular para verificar que sean netras de la A a la Z, sin importar la cantidad de
    caracteres, se deja de evaluar la palabra cuando se reconozca un espacio, los siguientes
    mensajes se muestran en consola para guiar al usuario en dado caso que sea necesario.
     */

    private void crearYEvaluarSubcadenas(String textoEvaluar) {

        if (Pattern.compile("[a-z]+[a-z]?\n?").matcher(textoEvaluar).find()) {
//                    if (Pattern.compile("[a-z]+\n?").matcher(textoEvaluar).find()) {

            textoEvaluar = textoEvaluar.trim();
            String palabras[] = textoEvaluar.split("(\\s|\n)");

            for (int i = 0; i < palabras.length; i++) {
                Cadena cadena = new Cadena();
                cadena.setCadena(palabras[i].trim());
                String resultado = busquedadDiccionario.obtenerPrimeraEvaluacion(cadena.getCadena());
                if (resultado.compareTo("No es una palabra Valida") == 0) {
                    cadena.setMensaje("No es una palabra Valida");
                    cadena.setEstado(false);
                    this.cadenasIncorrectas.add(cadena);
                    agregarPalabraConErrorVista();
                    quitarPalabrasInexistentes(palabras);

                } else if (resultado.compareTo("Cumple") == 0) {
                    cadena.setMensaje("quizás quiso decir...?");
                    cadena.setEstado(false);
                    this.cadenasIncorrectas.add(cadena);
                    agregarPalabraConErrorVista();
                }
            }
            quitarPalabrasInexistentes(palabras);
        }
    }

    /* El programa permite el ingreso de cualquier palabra, independientemente si
    el error esta desde el inicio de la escritura, se hace con la intención de que 
    cualquier cadena pueda ser evaluada en la lista y modificada si es el caso.
     */

    private void agregarPalabraConErrorVista() {
        Iterator<Cadena> it = this.cadenasIncorrectas.iterator();
        DefaultListModel modeloT = new DefaultListModel();
        while (it.hasNext()) {
            String cadena = it.next().getCadena();
            modeloT.addElement(cadena);
        }
        this.vistaPrincipal.getjListErrorPalabras().setModel(modeloT);

    }

    /* Método con el cual nos ayudamos a evitar que el usuario ingrese una 
    palabra que sature el programa, ya sea por ser demasiado extensa o porque 
    no tiene sentido, se daran algunas sugerencias con respecto a la primera letra
    ingresada, al ser una cadena que no se pudo verificar en el diccionario, se activa 
    una bandera la cual actua borrando la palabra.
     */
    private void quitarPalabrasInexistentes(String palabras[]) {
        Set<Cadena> cadenasBorrar = new HashSet<>();
        boolean flag = false;
        for (Cadena cadena : this.cadenasIncorrectas) {
            for (int i = 0; i < palabras.length; i++) {
                if (palabras[i].compareTo(cadena.getCadena()) == 0) {
                    flag = true;
                }
            }
            if (flag == false) {
                cadenasBorrar.add(cadena);
            }
        }
        for (Cadena c : cadenasBorrar) {
            this.cadenasIncorrectas.remove(c);
        }
        agregarPalabraConErrorVista();
    }
}
