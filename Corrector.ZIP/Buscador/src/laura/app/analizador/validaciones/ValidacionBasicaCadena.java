/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package laura.app.analizador.validaciones;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Laura Camacho, Jessica Garcia & Alán Bohorquez
 */


/* Se manejan las expresiones regulares (7) para realizar la respectiva busqueda 
en el diccionario, en este apartado vemos lo que es valido e invalido, su respectiva 
regla, cantidad de caracteres permitidos y su mensaje en dado caso que no sea 
correcto lo que se escribe.
*/
public class ValidacionBasicaCadena {

    private final String CARACTERES_INVALIDOS = "[0-9]+|[\\+\\*\\/&]";
    private final String CONSONANTES_SEGUIDOS_INVALIDOS = "[b-df-hj-np-tv-z]{3,}";
    private final String VOCALES_SEGUIDAS_INVALIDOS = "(a|e|i|o|u){4,}";
    private final String CANTIDAD_VOCALES_SEGUIDAS_VALIDAS = "(a|e|i|o|u){3}";
    private final String TRIPTONGO_VALIDO = "(u|i)(a|e|o)(u|i)";
    private final String M_ANTES_DE_P_B = "n(p|b)";
    private final String DOBLE_R_VALIDO = "^rr|rr$";

    public ValidacionBasicaCadena() {

    }
    /*
    Método que se usa como advertencia en dado caso que no se haya cumplido algo
    de las expresiones regulares, se muestra en consola para evitar que el programa
    tome el mensaje como palabras a evaluar.
    */
    public String validacionBasicaCadena(String palabra) {

        if (palabra == null) {
            return "cadena invalida";
        } else if (Pattern.compile(this.CARACTERES_INVALIDOS).matcher(palabra).find()) {
            return "Contiene Signos Invalidos";
        } else if (Pattern.compile(this.CONSONANTES_SEGUIDOS_INVALIDOS).matcher(palabra).find()) {
            return "Contiene consonantes seguidas invalidas";
        } else if (Pattern.compile(this.VOCALES_SEGUIDAS_INVALIDOS).matcher(palabra).find()) {
            return "Contiene vocales seguidas invalidas";
        } else if (Pattern.compile(this.M_ANTES_DE_P_B).matcher(palabra).find()) {
            return "Se debe de escribir M antes de P o B";
        } else if (Pattern.compile(this.DOBLE_R_VALIDO).matcher(palabra).find()) {
            return "Nunca se usa RR al principio o final de una palabra";
        } else {
            if (Pattern.compile(this.CANTIDAD_VOCALES_SEGUIDAS_VALIDAS).matcher(palabra).find()) {
                if (!Pattern.compile(this.TRIPTONGO_VALIDO).matcher(palabra).find()) {
                    return "Triptongo invalido";
                }
            }
            return "Cumple";
        }
    }
}