/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package laura.app.analizador.archivos;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Laura Camacho, Jessica Garcia & Alan Bohorquez  
 * @Clase creada con la intención de extraer todo lo que este en el
 * archivo del diccionario, se hace por medio de una lista para poder leer todo
 * el documento
 */
public class ArchivoDiccionario {

    //private final String NOMBRE_ARCHIVO_DICCIONARIO = "diccionario.txt";
    private List<String> diccionario;
    private FileReader in;
    private static ArchivoDiccionario manejoArchivos;

    private ArchivoDiccionario() {
        cargarArchivo();
    }

    /*
    Método donde se especifica la ruta en donde se encuntra almacenado el 
    documento con terminal txt para que sea mas sencilla la modificación de 
    alguna palabra, en caso tal que no se encuentra, se activa la notificación 
    de "archivo no encontrado"
     */
    private void cargarArchivo() {
        try {
            this.in = new FileReader(System.getProperty("user.dir") + "\\resources\\diccionario.txt");
            //
            //this.in = getClass().getClassLoader().getResourceAsStream(this.NOMBRE_ARCHIVO_DICCIONARIO);
            if (in != null) {
                diccionario = readFromInputStream(in);
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ArchivoDiccionario.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /* Por medio de un "BufferedReader", que es una clase de Java se lee el documento
    en secuencia de entrada (Archivo txt) donde se comienzan a leer las lineas
    que van separadas por un salto de linea
    
     */
    private List<String> readFromInputStream(FileReader file) {
        List<String> palarasDiccionario = null;
        try {
            palarasDiccionario = new ArrayList<>();
            BufferedReader br = new BufferedReader(file);
            String linea;
            while ((linea = br.readLine()) != null) {
                String lineas[] = linea.split("\n");
                for (String palabra : lineas) {
                    palarasDiccionario.add(palabra);
                }
            }
            return palarasDiccionario;
        } catch (IOException ex) {
            return palarasDiccionario;
        }
    }

    /* Se usa con la intención de que la información del diccionario no sea nula
    y por ende se maneje de una mejor manera el manejo del arhivo
    
     */
    public static ArchivoDiccionario getInstance() {
        if (manejoArchivos == null) {
            manejoArchivos = new ArchivoDiccionario();
        }
        return manejoArchivos;
    }

    public List<String> getDiccionario() {
        return this.diccionario;

    }
}
