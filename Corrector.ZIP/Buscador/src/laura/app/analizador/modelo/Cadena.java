/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package laura.app.analizador.modelo;

import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author Laura Camacho, Jessica Garcia & Alan Bohorquez
 */

/* En esta clase se busca difereciar lo que es la cadena, el mensaje, el estado y 
las alternativas.
- Cadena: palabra a evaluar
- Estado: Palabra correcta / Palabra incorrecta
- Mensaje: Se usa por medio de las expresiones regulares para conocer cual fue el 
motivo del error
- Alternativas: Palabras más cercanas (coincidentes) a la palabra erronea para posteriormente 
poder reemplazarla.
 */

public class Cadena {

    private String cadena;
    private String mensaje;
    private boolean estado;
    private Set<String> cadenasAlternativas;

    public Cadena() {
        this.cadenasAlternativas = new HashSet<>();
    }

    public Set<String> getCadenasAlternativas() {
        return cadenasAlternativas;
    }

    public void setCadenasAlternativas(Set<String> cadenasAlternativas) {
        this.cadenasAlternativas = cadenasAlternativas;
    }

    public String getCadena() {
        return cadena;
    }

    public void setCadena(String cadena) {
        this.cadena = cadena;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    /**
     * @return the mensaje
     */
    public String getMensaje() {
        return mensaje;
    }

    /**
     * @param mensaje the mensaje to set
     */
    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    @Override
    public boolean equals(Object o) {
        if (o instanceof Cadena) {
            Cadena p = (Cadena) o;
            return this.cadena.equals(p.cadena);
        }
        return false;

    }

    @Override
    public int hashCode() {
        return cadena.length();
    }

    @Override
    public String toString() {
        return "Cadena{" + "cadena=" + cadena + ", mensaje=" + mensaje + ", estado=" + estado + "\ncadenasAlternativas=" + cadenasAlternativas + '}';
    }

}
