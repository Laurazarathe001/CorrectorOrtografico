/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package laura.app.analizador.ejecucion;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import laura.app.analizador.controlador.Controlador;
import laura.app.analizador.manejo_diccionario.BusquedadDiccionario;
import laura.app.analizador.views.VistaPrincipal;
import mdlaf.MaterialLookAndFeel;
import mdlaf.themes.MaterialOceanicTheme;

/**
 *
 * @author Laura Camacho, Jessica Garcia & Alan Bohorquez
 * @clase En la clase prinicpal se activan las librerias necesarias, en este
 * caso tanto para la interfaz como para buscar las palabras en el diccionario
 */
public class Principal {

    public static void main(String[] args) {

        try {
            UIManager.setLookAndFeel(new MaterialLookAndFeel());
            MaterialLookAndFeel.changeTheme(new MaterialOceanicTheme());
            VistaPrincipal vista = new VistaPrincipal();
            Controlador controlador = new Controlador(vista, new BusquedadDiccionario());
            controlador.start();
        } catch (UnsupportedLookAndFeelException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
